1. Overview

Simple decal System is editor only extension.
It supports meshes, terrains, static, not static objects and unity's sprites.

2. Getting started

2.1 Press GameObject/Decal to create new decal. Or you can copy/paste existing decal.
2.2 Choose material and sprite. Note: Texture of material must have sprites and path to material and texture must contain "decal" word.
2.3 By default decals are static and they are affected only by static objects. If you need you can make decal not static and then decal will be affected by not static objects.
2.4 You can press Left Ctrl + Left Mouse Button to simply set position of decal.

3. Links

https://bitbucket.org/Deni35-team/unity-simple-decal-system
http://u3d.as/6gt