﻿namespace VLB
{
    public static class Version
    {
        public const int Current = 1890;
    }
}
