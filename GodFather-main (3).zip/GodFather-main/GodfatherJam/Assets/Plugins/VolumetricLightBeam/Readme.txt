Hi and thank you for using the Volumetric Light Beam plugin for Unity!
You can find here some resources to help your first steps.

*******************
** Documentation **
*******************
Please visit: http://saladgamer.com/vlb-doc/

**************************
** Configure the plugin **
**************************
- For the Built-in Render Pipeline: nothing to do!
- For the Universal Render Pipeline (URP): http://saladgamer.com/vlb-doc/render-pipelines/#universal-render-pipeline-urp
- For the High Definition Render Pipeline (HDRP): http://saladgamer.com/vlb-doc/render-pipelines/#high-definition-render-pipeline-hdrp

And that's it! You can start to create new volumetric lights!

Thank you very much, and do not hesitate to contact the team for any questions or suggestions: techsaladunity@gmail.com

Cheers!
